"""Train REINFORCE with baseline using the same env pipeline as EfficientZero.

    python -m src.reinforce.train --config configs/pong.yaml

Uses fixed-length rollouts with GAE (Generalized Advantage Estimation) for
stable learning.  This is the practical variant of REINFORCE with baseline
that actually converges on Atari -- sometimes called "advantage actor-critic"
or A2C in the literature.
"""
from __future__ import annotations

import argparse
import json
import os

import numpy as np
import torch
import torch.nn.functional as F
from torch.distributions import Categorical

from ..common.atari_wrappers import make_atari, num_actions
from ..common.config import load_config, parse_overrides, save_config
from ..common.logger import CheckpointManager, RunLogger
from ..common.utils import Timer, count_parameters, ensure_dir, get_device, set_seed
from .model import ReinforceNet


def build_model(cfg, action_space_size, device):
    c = 1 if cfg.env.grayscale else 3
    obs_shape = (cfg.reinforce.stack * c, cfg.reinforce.size, cfg.reinforce.size)
    model = ReinforceNet(obs_shape, action_space_size).to(device)
    return model, obs_shape


def make_env(cfg, seed, eval_mode=False):
    return make_atari(
        game=cfg.env.game,
        size=cfg.reinforce.size,
        grayscale=cfg.env.grayscale,
        stack=cfg.reinforce.stack,
        skip=cfg.env.skip,
        episodic_life=(not eval_mode) and bool(cfg.env.episodic_life),
        clip_rewards=not eval_mode,
        sticky_actions=cfg.env.sticky_actions,
        max_episode_steps=cfg.env.eval_max_episode_steps if eval_mode else cfg.env.max_episode_steps,
        seed=seed,
    )


@torch.no_grad()
def quick_eval(cfg, model, device, episodes: int = 3, seed: int = 321):
    env = make_env(cfg, seed, eval_mode=True)
    model.eval()
    returns = []
    for ep in range(episodes):
        obs, _ = env.reset(seed=seed + ep)
        done, total = False, 0.0
        while not done:
            policy_logits, _ = model(torch.as_tensor(obs[None], device=device))
            action = int(policy_logits.argmax(dim=1).item())
            obs, reward, terminated, truncated, _ = env.step(action)
            total += float(reward)
            done = terminated or truncated
        returns.append(total)
    env.close()
    model.train()
    return float(np.mean(returns)), float(np.std(returns))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/pong.yaml")
    ap.add_argument("--run-dir", default=None)
    ap.add_argument("--seed", type=int, default=None)
    ap.add_argument("--smoke", action="store_true")
    ap.add_argument("--set", nargs="*", default=[])
    args = ap.parse_args()

    cfg = load_config(args.config, parse_overrides(args.set))
    if args.smoke:
        cfg.reinforce.total_env_steps = 300
        cfg.reinforce.eval_interval = 10**9
        cfg.reinforce.checkpoints = [100, 300]
        cfg.reinforce.eval_episodes = 1
        cfg.env.max_episode_steps = 100
        cfg.env.eval_max_episode_steps = 100

    seed = args.seed if args.seed is not None else int(cfg.seed)
    set_seed(seed)
    device = get_device(cfg.device)
    run_dir = ensure_dir(args.run_dir or os.path.join(cfg.output_dir, f"reinforce_{cfg.env.game.lower()}"))
    save_config(cfg, os.path.join(run_dir, "config.yaml"))

    env = make_env(cfg, seed)
    action_space_size = num_actions(env)
    model, obs_shape = build_model(cfg, action_space_size, device)
    model.train()
    print(f"[reinforce] device={device} actions={action_space_size} params={count_parameters(model):,}", flush=True)

    optimizer = torch.optim.Adam(model.parameters(), lr=float(cfg.reinforce.lr))
    logger = RunLogger(run_dir, "REINFORCE")
    ckpt = CheckpointManager(run_dir, "reinforce", cfg.reinforce.checkpoints)
    timer = Timer()

    # Hyperparameters
    gamma = float(cfg.reinforce.gamma)
    gae_lambda = float(getattr(cfg.reinforce, "gae_lambda", 0.95))
    entropy_coeff = float(cfg.reinforce.entropy_coeff)
    max_grad_norm = float(cfg.reinforce.max_grad_norm)
    rollout_length = int(cfg.reinforce.rollout_length)
    total_env_steps = int(cfg.reinforce.total_env_steps)
    log_interval = int(cfg.reinforce.log_interval)
    eval_interval = int(cfg.reinforce.eval_interval)
    eval_episodes = int(cfg.reinforce.eval_episodes)

    def payload(env_steps, grad_steps, eval_score=None):
        return {
            "model": model.state_dict(),
            "cfg": json.loads(json.dumps(cfg, default=str)),
            "env_steps": int(env_steps),
            "training_steps": int(grad_steps),
            "wallclock_s": timer.elapsed(),
            "action_space_size": action_space_size,
            "obs_shape": obs_shape,
            "agent": "reinforce",
            "eval_score": eval_score,
        }

    obs, _ = env.reset(seed=seed)
    ep_return, ep_len, returns_hist = 0.0, 0, []
    grad_steps, last_eval = 0, 0
    last_loss, last_policy_loss, last_value_loss, last_entropy = (
        float("nan"), float("nan"), float("nan"), float("nan"),
    )

    step = 0
    while step < total_env_steps:
        # ===== Collect a rollout of `rollout_length` steps ========================
        rollout_log_probs = []
        rollout_values = []
        rollout_rewards = []
        rollout_dones = []
        rollout_entropies = []

        for _t in range(rollout_length):
            step += 1
            if step > total_env_steps:
                break

            obs_tensor = torch.as_tensor(obs[None], device=device)
            policy_logits, value = model(obs_tensor)
            dist = Categorical(logits=policy_logits)
            action_tensor = dist.sample()
            action = int(action_tensor.item())

            rollout_log_probs.append(dist.log_prob(action_tensor).squeeze(-1))
            rollout_values.append(value.squeeze(-1).squeeze(-1))
            rollout_entropies.append(dist.entropy().squeeze(-1))

            next_obs, reward, terminated, truncated, info = env.step(action)
            done = terminated or truncated
            rollout_rewards.append(float(reward))
            rollout_dones.append(float(done))

            ep_return += float(info.get("raw_reward", reward))
            ep_len += 1
            obs = next_obs

            if done:
                returns_hist.append(ep_return)
                ep_return, ep_len = 0.0, 0
                obs, _ = env.reset()

            # ----- logging / eval / checkpoints -----
            if step % log_interval == 0:
                logger.log({
                    "env_steps": step,
                    "train_steps": grad_steps,
                    "loss": last_loss,
                    "policy_loss": last_policy_loss,
                    "value_loss": last_value_loss,
                    "entropy": last_entropy,
                    "recent_return": float(np.mean(returns_hist[-10:])) if returns_hist else float("nan"),
                    "episodes": len(returns_hist),
                })

            if step - last_eval >= eval_interval:
                last_eval = step
                mean_r, std_r = quick_eval(cfg, model, device, episodes=eval_episodes, seed=seed + 5)
                logger.log({"env_steps": step, "train_steps": grad_steps, "eval_return": mean_r, "eval_std": std_r}, force_print=True)

            milestone = ckpt.due(step)
            if milestone is not None:
                score, _ = quick_eval(cfg, model, device, episodes=eval_episodes, seed=seed + 5)
                ckpt.save(milestone, payload(step, grad_steps, score), extra={"eval_score": score, "wallclock_s": timer.elapsed()})

        T = len(rollout_log_probs)
        if T == 0:
            break

        # ===== Compute GAE advantages and return targets ==========================
        values_t = torch.stack(rollout_values)        # (T,)
        log_probs_t = torch.stack(rollout_log_probs)  # (T,)
        entropies_t = torch.stack(rollout_entropies)  # (T,)

        with torch.no_grad():
            # Bootstrap value for the state after the last rollout step
            _, next_val = model(torch.as_tensor(obs[None], device=device))
            next_val = next_val.squeeze()
            vals_d = values_t.detach()

            # GAE(lambda) -- handles episode boundaries via the (1 - done) mask
            advantages = torch.zeros(T, device=device)
            gae = torch.tensor(0.0, device=device)
            for t in reversed(range(T)):
                next_v = next_val if t == T - 1 else vals_d[t + 1]
                delta = rollout_rewards[t] + gamma * (1.0 - rollout_dones[t]) * next_v - vals_d[t]
                gae = delta + gamma * gae_lambda * (1.0 - rollout_dones[t]) * gae
                advantages[t] = gae

            returns_target = advantages + vals_d

            # Normalize advantages for stable gradients
            if T > 1:
                advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-8)

        # ===== Compute losses and update ==========================================
        policy_loss = -(log_probs_t * advantages).mean()
        value_loss = F.mse_loss(values_t, returns_target)
        entropy_bonus = entropies_t.mean()

        loss = policy_loss + 0.5 * value_loss - entropy_coeff * entropy_bonus

        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_grad_norm)
        optimizer.step()

        grad_steps += 1
        last_loss = float(loss.item())
        last_policy_loss = float(policy_loss.item())
        last_value_loss = float(value_loss.item())
        last_entropy = float(entropy_bonus.item())

    ckpt.save_final(payload(min(step, total_env_steps), grad_steps), extra={"wallclock_s": timer.elapsed()})
    logger.close()
    env.close()
    print(f"[reinforce] done in {Timer.fmt(timer.elapsed())} -- {run_dir}", flush=True)


if __name__ == "__main__":
    main()
